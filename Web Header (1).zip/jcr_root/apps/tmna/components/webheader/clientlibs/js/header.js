document.addEventListener("DOMContentLoaded", function () {
    const header = document.querySelector(".header");

    window.addEventListener("scroll", function () {
        if (window.scrollY > 50) {
            header.style.background = "rgba(0,0,0,0.9)";
        } else {
            header.style.background = "rgba(0,0,0,0.6)";
        }
    });
});